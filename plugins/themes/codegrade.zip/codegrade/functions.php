<?php
include_once('plugins/jetpack_form_thankyou.php');
