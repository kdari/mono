<?php
/**
 * The template for displaying the footer.
 *
 * Closes the #content div, the #page div and the body.
 *
 * @package Codegrade_Custom_Theme
 */

?>

	</div><!-- #content -->

</div><!-- #page -->

<?php wp_footer(); ?>

<script src="<?php echo get_template_directory_uri() . '/js/smooth-scroll.min.js'; ?>"></script><script>smoothScroll.init();</script>
</body>
</html>
